# Sales Analytics – Power BI Project (PBIP)

Open **Sales Analytics.pbip** in Power BI Desktop, then click **Home > Refresh** once to load the data.
The data is embedded in each Power Query, so you don't need the Excel file or any file path.

## Model
- Fact tables: Sales, Targets. Dimensions: Products, Customers, Salespeople, Date (Jan 2025 – Dec 2026, marked as a date table).
- Relationships are many-to-one and single-direction. ID/key columns and raw fact columns are hidden.
- `_Measures` holds 34 measures in display folders: 1 Sales, 2 Customers, 3 Time Intelligence, 4 Targets, 5 Ranking.
- `Date[DateWithSales]` (hidden) limits LY/YTD/target comparisons to dates up to the last order (31 Oct 2026).
  This keeps the comparison fair for the partial year.

## Report pages
1. Executive Overview  2. Sales Performance  3. Product Analysis  4. Customer Insights  5. Trends.
The Year slicer is synced across all pages.

## Reference values to check after refresh (all years, no filters)
- Total Sales: AED 13,747,258 (2025: 7,010,773 / 2026: 6,736,486)
- Profit: AED 4,226,581, Margin %: 30.7%, Order Count: 2,500
- Year = 2026: YoY Growth % = 22.5% (compared with Jan–Oct 2025)
- Target Achievement % (all, to date): 98.4%
